import java.util.*;
public class Number implements Comparable<Number> {
  private DigitList number; //DigitList for maintainance of nodes
  private int digitCount = 0; // counts the number of nodes attached to the high including the high
  private int decimalPlaces = 0; //number of digits after decimal place
  private boolean negative = false; // sign (positive or negative)
 
  // Constructor 
  Number(){  
    number = new DigitList();
    digitCount = 0;
    decimalPlaces = 0;
    negative = false;
  }
  
  // Constructor that takes a String representation of a number 
  // (e.g. "-21.507"). Calls method accept().
  public Number(String str){
    validate(str); // helps in clarifying whether the str has any characters or not
    this.accept(str); //converts the inputted numbers     
  }
 
  // Builds a DigitList representation of the number represented by str   
  public void accept(String str){
    digitCount = 0;
    String str_high = "";
    DigitList new_number = new DigitList();
    int str_int = 0;
    int count_point = 0;
    
    if(str_high.equals("0")){
      new_number.addLast(0);
      number = new_number;
      return;
    }
    for(int i = 0; i < str.length();i++){
      count_point++;
      if(str.charAt(i) == '-'){
        negative = true;
        continue;
      }
      if(str.charAt(i) != '.'){
        str_int = Integer.parseInt(str.charAt(i) + "");
        new_number.addLast(str_int);
        digitCount++;
      }
      else{
        decimalPlaces = str.length()-count_point;
      }
    }
    number = new_number; //manages the number by converting the string 
  }                      //into a digit
  
  
  public void validate(String str){//checks whether the number doesn't 
    String z ="";                  // have character
    int j = 0;
    for(int i = 0;i < str.length();i++){
      z = str.substring(i,i+1);
      try{
        if(z.equals("-") || z.equals(".")){
          i++;
        }
        else{
          z = str.substring(i,i+1);
          j = Integer.parseInt(z);
        }
      }
      catch(NumberFormatException e){
        if(!z.equals("-") && !z.equals(".")){
          System.out.println("This is not an Integer " + j);
        }
      }
    }
  }
  
  
  public Number add(Number n){      //checks for the signs and assigns them
    Number new_num = new Number();  //correctly
    if(n.negative != negative){
      Boolean a = n.negative;
      n.negative = negative;
      new_num = this.subtract(n);   //when the the signs are different  
      n.negative = a;               //it subtracts
      if(this.negative == n.negative){
        if(this.compareTo(n) == 1){new_num.negative = this.negative;}
        else if(this.compareTo(n) == -1){new_num.negative = n.negative;}
        else{new_num.negative = false;}
    }
      
      
      return new_num;
    }
    return addAbsolute(n);
  }
  
  // Returns a Number that represents "this - n". 
  // Target Complexity: O(n)
  public Number subtract(Number n){
    Number new_num = new Number();
    boolean after = true;
    if(n.negative != this.negative){//conditions for having different signs
      boolean temp = n.negative;
      if(this.negative == true && n.negative == false){
        after = true;
      }
      if(this.negative == false && n.negative == true){
        after = false;
      }
      n.negative = negative;
      new_num = this.add(n);
      new_num.negative = after;
      n.negative = temp;
      return new_num;
    }
    boolean h = n.negative;
    boolean g = negative;
    boolean z = false;
    negative = false;
    n.negative = false;
    if(h == false && g == false){
      z = true;
    }
    if(this.compareTo(n) == 1){
      new_num = this.subtractAbsolute(n);
      if(z == true){
        new_num.negative = false;
      }else{
        new_num.negative = true;//g;
      }
    }
    else if(this.compareTo(n) == -1){
      new_num = n.subtractAbsolute(this);
      if(z == true){
        new_num.negative = true;
      }
      else{
        new_num.negative = false;//h;
      }
    }
    else{
      new_num = this.subtractAbsolute(n);
      new_num.negative = false;
    }
    new_num.digitCount = this.digitCount;
    new_num.decimalPlaces = this.decimalPlaces;
    
    return new_num;
  }
  
  protected Number subtractAbsolute(Number n){//substracts n from this
    Number difference = new Number();
    int borrow = 0;
    Node temp = this.number.low;
    Node temp_n = n.number.low;
    
    while(temp != null){
      int newDigit = temp.data-temp_n.data;
      newDigit -= borrow;
      if(newDigit < 0){
        newDigit += 10;
        borrow = 1;
      }
      else{
        borrow = 0;
      }
      
      difference.number.addFirst(newDigit);      
      temp = temp.prev;
      temp_n = temp_n.prev;
    }
    return difference;
  }
  
  //Reverses the value of negative. 
  public void reverseSign(){
    if(negative == true){
      negative = false;
    }
    else if(negative == false){
      negative = true;
    }
  }
  
  public void trim(){//removes excess 0s
    if(this.decimalPlaces == this.digitCount && this.digitCount == 0){
      number = new DigitList();
      number.addLast(0);
      return;
    }
    int b = this.digitCount;
    int a = this.decimalPlaces;
    boolean back = false;
    boolean front = false;
    if(a == b && a == 0){
      back = true;
      front = true;
    }

    Node temp = this.number.low;
    Node temp_n = this.number.high;
    int count = 0;
    int acount = b - a;
    int another = b - a;
    while(temp != null){
      if(count == a){
        temp.next = null;
        break;
      }
      if(temp.data != 0){
        back = true;
        break;
      }
      count++;
      temp = temp.prev;
    }
    int h = count;
    count = 0;
    while(temp_n != null){
      if(acount == count){
        if(temp_n.next != null){
          temp_n.prev = null;
          front = true;
        }
        break;
      }
      if(temp_n.data != 0){
        front = true;
        break;
      }
      count++;
      temp_n = temp_n.next;
    }
    if(back == true){
      this.number.low = temp;
      temp.next = null;
    }
    if(front == true){
      this.number.high = temp_n;
      temp_n.prev = null;
    }
    this.decimalPlaces = a - h;
    this.digitCount = b -(count + h);
  }
  
  // Implements compareTo of Comparable
  public int compareTo(Number n){//calls the private method
    return compareToAbsolute(n);
  }
  
  
  private Number addAbsolute(Number n){//private method for addition
    Number sum = new Number();
    this.compareTo(n);
    if(this.negative == n.negative){
      if(this.compareTo(n) == 1){sum.negative = this.negative;}
      else if(this.compareTo(n) == -1){sum.negative = n.negative;}
      else{sum.negative = false;}
    }
    
    int carry = 0;
    Node temp = number.low;
    Node temp_n = n.number.low;
    
    while(temp != null){
      int newDigit = temp.data + temp_n.data + carry;
      sum.number.addFirst(newDigit % 10);
      sum.digitCount++;
      carry = newDigit / 10;
      temp = temp.prev;
      temp_n = temp_n.prev;
    }
    if(carry != 0){
      sum.number.addFirst(1);
      sum.digitCount++;
    }
    sum.decimalPlaces = decimalPlaces;
    return sum;
  }
  
  public Number multiply(Number n){//multiplies this*n and sets the appropriate the sign
    boolean t = this.negative;
    boolean a = n.negative;
    this.negative = n.negative;
    Number product = new Number();
    Node temp_n = n.number.high;
    while(temp_n != null){
      Number partialProduct = new Number();
      int carry = 0;
      Node temp = this.number.low;
      while(temp != null){
        int newDigit = (temp.data * temp_n.data) + carry;
        carry = newDigit / 10;
        newDigit = newDigit % 10;
        partialProduct.number.addFirst(newDigit);
        partialProduct.digitCount++;
        temp = temp.prev;
      }
      if(carry != 0){
        partialProduct.number.addFirst(carry);
        partialProduct.digitCount++;
      }
      product.number.addLast(0);
      product.digitCount++;
      product = product.addAbsolute(partialProduct);
      temp_n = temp_n.next;
    }

    product.decimalPlaces = this.decimalPlaces + n.decimalPlaces;
    if(t != a ){
      product.negative = true;
    }
    else{
      product.negative = false;
    }
    return product;
  }
  
  public String toString(){//converts the number list into a string 
    this.trim();
    String a = "";
    if(this.decimalPlaces == this.digitCount && this.digitCount == 0){
      return "0";
    }
    if(negative == true){
      a += "-";
    }
    int count = 0;
    Node temp = number.high;
    while(temp != null){
      if(count == (this.digitCount - this.decimalPlaces)){
        a += ".";
      }
      a += temp.data;
      temp = temp.next;
      count++;
    }
    String str = "";
    String b = "";
    count = this.digitCount;
    if(this.decimalPlaces > this.digitCount){
      while(count < this.decimalPlaces){
        str += "0" + a;
        count++;
      }
      b = str;
      str = "";
      str += "." + b;
       a = str;
    }
    
   
    return a;
  }
  
    
  private int compareToAbsolute(Number n){//private method for compareTo
    if(this.negative == true && n.negative == false){
      return -1;
    }
    if(this.negative == false && n.negative == true){
      return 1;
    }
    int forloop = 0;
    int digits_before_n = n.digitCount - n.decimalPlaces;
    int digits_before = digitCount - decimalPlaces;
    int d_after = decimalPlaces;
    int d_n_after = n.decimalPlaces;
    if(digits_before_n > digits_before){
      for(int e = 0;e < (digits_before_n-digits_before);e++){
        number.addFirst(0);
      }
      forloop += digits_before_n;
      digits_before = digits_before_n;
      n.digitCount = digitCount;
            
    }
    else{
      for(int e = 0;e < (digits_before-digits_before_n);e++){
        n.number.addFirst(0);
      }
      forloop += digits_before;
      digits_before_n = digits_before;
      digitCount = n.digitCount;
    }
    if(decimalPlaces < n.decimalPlaces){
      for(int e = 0;e < (n.decimalPlaces-decimalPlaces);e++){
        number.addLast(0);
      }
      forloop += d_n_after;
      decimalPlaces = n.decimalPlaces;
      d_after = d_n_after;
    }
    else{
      for(int e = 0;e < (decimalPlaces - n.decimalPlaces);e++){
        n.number.addLast(0);
      }
      forloop += d_after;
      n.decimalPlaces = decimalPlaces;
      d_n_after = d_after;
    }
    n.digitCount = forloop;
    digitCount = forloop;
    Node temp = number.high;
    Node temp_n = n.number.high;
    int bigger = 0;
    for(int j = 0; j < forloop;j++){
      if(temp.data > temp_n.data){
        if(n.negative == true && negative == true){
          return -1;
        }
        return 1;
      }
      if(temp.data < temp_n.data){
        if(n.negative == true && negative == true){
          return 1;
        }
        return -1;
      }
      temp = temp.next;
      temp_n = temp_n.next;
    }
    
    return 0;
  }
}