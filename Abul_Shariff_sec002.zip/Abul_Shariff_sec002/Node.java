public class Node{
  protected Node prev;                                           //For creating the DigitList
  protected Node next;                                           //same purpose as above
  protected int data;                                            //storing the data
  
  // Constructor initializes data members.
  // Target Complexity: O(1)
  public Node(int data, Node prev, Node next){
    this.data = data;
    this.prev = prev;
    this.next = next;
  }
  
  // Create a pretty representation of the Node
  // Format: [data]. Example: [3]
  // Target Complexity: O(1)
  public String toString(){
    String ans = "[";
    ans += data;
    ans += "]";
    return ans;
  }
  
}