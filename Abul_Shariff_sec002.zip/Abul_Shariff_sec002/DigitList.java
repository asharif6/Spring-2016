import java.util.*;

public class DigitList{ //Helps maintain the whole the list of Nodes from that would be acquired 
  protected Node high;  // reference to the node with the high-order digit
  protected Node low;   // reference to the node with the low-order digit
  protected int size;   // number of nodes
  protected int modCount;

  DigitList(){         //constructor
    this.high = null;
    this.low = null;
    this.size = 0;
    this.modCount = 0;
    
  }
  public void addFirst(int x){             //adds the first node into the list by converting int into a Node
    Node newNode = new Node(x,null,null);
    if(this.high == null){
      this.high = newNode;
      this.low = newNode;
      size++;
      return;
    }
    newNode.next = this.high;
    newNode.prev = null;
    this.high.prev = newNode;
    this.low.next = null;
    this.high = newNode;
    size++;
  }
  
  // Returns digit high (at the front of the list). 
  public int getFirst(){
    return this.high.data;
  }
  // Removes digit high at the front of the list. 
  public void removeFirst(){
    this.high = this.high.next;
    this.high.prev = null;
    size--;
  }
  
  // Add digit x to the end of the list. 
  public void addLast(int x){
    if(this.low == null){
     
      Node newNode = new Node(x,null,null);
      this.high = newNode;
      this.low = newNode;
      size++;
      return;
    }
    Node newNode = new Node(x,this.low,null);
    this.low.next = newNode;
    this.low = newNode;
    size++;
  }
  
  // Returns digit low (at the end of the list). 
  public int getLast(){
    return this.low.data;
  }
  
  // Removes digit low at the end of the list. 
  public void removeLast(){
    this.low = this.low.prev;
    this.low.next = null;
    size--;
  }
  // Returns a pretty representation of the nodes in the list.
  // (Note that a DigitList has no notion of a decimal point.)
  // Example: [3][1][4][1][6]
  public String toString(){
    if(this.high == null){return "[]";}
    Node temp = this.high;
    String getit = "";
    while(temp != null){
      getit += temp.toString();
      temp = temp.next;
    }
    return getit;
  }
  // Returns the current size of the list
  public int size(){
    return this.size;
  }
}  
  
  
  
  
  
  
  
  
  
  
  