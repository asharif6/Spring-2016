import java.util.*;
public class Calculator{

  public static Number check(String ba){// A form of Validation for Calculator
    Number value = new Number();
    String z ="";
    int j = 0;
    for(int i = 0;i < ba.length();i++){
      z = ba.substring(i,i+1);
      try{
        if(z.equals("-") || z.equals(".")){
          i++;
        }
        else{
          z = ba.substring(i,i+1);
          j = Integer.parseInt(z);
        }
      }
      catch(Exception e){
        if(!z.equals("-") && !z.equals(".")){
          System.out.println("This is not an Integer " + j);
          value = null;
          return value;
        }
      }
    }
    value = new Number(ba);
    return value;
  }
  
  public static void main(String[] args){// the main method does the calculation by implement the number
  
    Number value = null;
    Number addvalue;
    Number subtractvalue;
    Number multiplyvalue;
    String h = "enter a value: e     add: a\nsubtract: s          multiply: m\nreverse sign: r      clear: c\nquit: q";
    Scanner a = new Scanner(System.in);
    Scanner b = new Scanner(System.in);
    String ab = "a.next()";
    String ba = "k";
    String z = "";
    int j = 0;
    while(!ab.equals("q")){
      System.out.println(h);
      ab = a.next();
      if(ab.equals("e")){
        System.out.println("Value you Want to Enter: ");
        ba = b.next();
        value = check(ba);
        System.out.println("Your value is " + value);
      }
      if(ab.equals("a")){
        System.out.println("Value you want to add: ");
        ba = b.next();
        addvalue = check(ba);
        value = value.add(addvalue);
        System.out.println(" You new Value is " + value);
      }
      if(ab.equals("s")){
        System.out.println("Value you want to subtract :");
        ba = b.next();
        subtractvalue = check(ba);
        value = value.subtract(subtractvalue);
        System.out.println("Your new Value is " + value);
      }
      if(ab.equals("m")){
        System.out.println("Value you want to multiply :");
        ba = b.next();
        multiplyvalue = check(ba);
        value = value.multiply(multiplyvalue);
        System.out.println("Your new Value is " + value);        
      }
      if(ab.equals("c")){
        value = new Number("0");
        System.out.println("Your new Value is " + value);
      }
      if(ab.equals("r")){
        value.reverseSign();
        System.out.println("Your new vale is " + value);
      }
        
    }
  
  }
}