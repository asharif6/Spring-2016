public class Node<T> {
  protected static final int NULL = -1;
  protected int previous;
  protected int next;
  protected T data;
 
  // Constructor initializes data members. See method init().
  protected Node(){
    this.init();
  }
 
  // Create a pretty representation of the pool
  // Format: [previous,next,data]
  // Target Complexity: O(n)
  public String toString(){
    String a = String.format("[%d,%d,%s]",this.previous,this.next,this.data);
    return a;
  }
 
  // Initializes the data members. 
  // Called by the constructor and also by method reset() 
  // in class NodePool.
  // Target Complexity: O(1)
  protected void init(){
    this.next = NULL;
    this.previous = NULL;
    this.data = null;
  }
}