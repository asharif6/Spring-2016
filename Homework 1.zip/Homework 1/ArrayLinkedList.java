import java.util.*;
class ArrayLinkedList<T> {
    protected final static int NULL = -1;      
    protected ArrayList<Node<T>> array;
    protected NodePool<T> pool;
    protected int head; // position of dummy node in array
    protected int tail; // position of tail node in array
    protected int firstEmpty; // head of the list of empty nodes
    protected int numberEmpty; // number of empty nodes
    protected int size; // number of non-empty nodes
    protected int modCount; // number of modifications made
    protected final static int NODEPOOLSIZE = 8;
 
    // Constructor to initialize the data members, increment modCount,
    // create the dummy header Node, and add it to array
    public ArrayLinkedList(){
      this.head = 0;///Initialized all the fields
      this.tail = 0;
      this.firstEmpty = NULL;
      this.numberEmpty = 0;
      this.size = 0;
      this.modCount = NULL;
      Node<T> dummy = new Node<T>();
      this.pool = new NodePool<T>(NODEPOOLSIZE);
      this.array = new ArrayList<Node<T>>();
      dummy.data = null;
      dummy.next = NULL;
      dummy.previous = NULL;
      array.add(0,dummy);
    }
    // Return number of non-empty nodes
    // Target Complexity: O(1)
    public int size(){
      return size;
    }
    
    
    // Return number of empty nodes
    // Target Complexity: O(1)
    public int numberEmpty(){
      return numberEmpty;
    }
    
      // convenience methods for debugging and testing
    protected int getFirstEmpty(){
      return firstEmpty;
    }
    // return firstEmpty
    protected int getHead(){
      return this.head;
    }// return head
      
    protected int getTail(){
      return this.tail;
    }// return tail
     
    
    protected ArrayList<Node<T>> getArray(){
      return array;
    }// return array
    
        // Appends the specified element to the end of this list. 
    // Returns true.
    // If no empty Nodes are available, then get a new Node from pool.
    // Throws IllegalArgumentException if e is null.
    // Checks assertions at the start and end of its execution.
    // Target Complexity: Amortized O(1)
    //////when added all the nodes are updated
    public boolean add(T e) {
        assert size>=0 && head==0 && numberEmpty >=0 && (numberEmpty==0  
         && firstEmpty==NULL) || (numberEmpty>0 && firstEmpty!=NULL)
          && (array.size() == size+numberEmpty+1);         
        //MY CODE
        if(e == null){
          throw new IllegalArgumentException();
        }
        Node<T> newNode;
        int use_in_the_end = NULL;
        if(firstEmpty != NULL){
          use_in_the_end = array.get(firstEmpty).next;
        }
        if(numberEmpty() > 0){
          int inde = firstEmpty;
          newNode = pool.create();
          newNode.data = e;
          array.set(inde,newNode);
          this.numberEmpty--;
          
        }else{
          newNode = pool.allocate();
          newNode.data = e;
          array.add(newNode);
        }
        
        this.size++;
        if(array.get(0).next == 0){
          array.get(0).next = array.indexOf(newNode);
        }
        if(tail == NULL){newNode.previous = 0;}
        else{newNode.previous = getTail();}
        newNode.next = NULL;
        if(tail != NULL){array.get(tail).next = array.indexOf(newNode);}
        tail = array.indexOf(newNode);
        if(numberEmpty == 0){
          firstEmpty = NULL;
        }
        if(use_in_the_end != NULL){
          firstEmpty = use_in_the_end;
        }
        //ENDS HERE
        // check this assertion before each return statement
        assert size>0 && head == 0 && numberEmpty >=0 
          && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
            && firstEmpty!=NULL)
            && (array.size() == size+numberEmpty+1);
        return true;
    }
     // Inserts the specified element at the specified index in this list.  
    // Shifts the element currently at that index (if any) and any 
    // subsequent elements to the right (adds one to their indices).    
    // Throws IndexOutOfBoundsException if the index is out of range 
    // (index < 0 || index > size()).
    // Throws IllegalArgumentException if e is null.
    // Can call add(T e) if index equals size, i.e., add at the end
    // Checks assertions at the start and end of its execution.
    // Target Complexity: O(n)
    public void add(int index, T e) {
      assert size>=0 && head==0 && numberEmpty >=0 
        && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
           && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
      //MY CODE
      if(index < 0 || index > size()){  
        throw new IndexOutOfBoundsException();
      }
      if(e == null){
        throw new IllegalArgumentException();
      }
      if(index == size()){
        this.add(e);
        return;
      }
      Node<T> newNode = pool.allocate();
      newNode.data = e; 
      int nullnode = 0;
      int changenode = 0;
      int count = 0;
      int h = array.get(0).next;
      for(int i = 1;i < array.size();i++){
        if(array.get(i).previous == NULL && array.get(i).data == null){
          if(firstEmpty != NULL){
            nullnode = getFirstEmpty();
            this.firstEmpty = array.get(this.getFirstEmpty()).next;
          }
          else{
            nullnode = i;
          }
        }
        
        if(h == NULL){
          continue;
        }
        
        if(array.get(h).next != NULL && array.get(h).data != null){
          if(index == count){
            changenode = h;
          }
          count++;
        }
        else if(array.get(h).previous != NULL && array.get(h).data != null){
          if(index == count){
            changenode = h;
          }
          count++;
        }
        
        if(array.get(h).next == NULL){continue;}
        else{h = array.get(h).next;}                  
        
      }
      
      //head and tail will change
      if(nullnode != 0){
        array.set(nullnode,newNode);
        newNode.next = changenode;
        newNode.previous = array.get(changenode).previous;
         array.get(changenode).previous = nullnode;
         array.get(newNode.previous).next = nullnode;
       }   
       else{
         array.add(newNode);
  
         int newnode_index = array.indexOf(newNode);
         newNode.next = changenode;
         newNode.previous = array.get(changenode).previous;
         array.get(changenode).previous = newnode_index;
         array.get(newNode.previous).next = newnode_index;
         if(newNode.next == NULL){
           tail = array.indexOf(newNode);
         }
       }
       if(numberEmpty() > 0){
         this.numberEmpty--;
       }
       this.size++;
       //ENDS HERE
       // check this assertion before each return statement
       assert size>0 && head==0 && numberEmpty >=0 
         && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
             && firstEmpty!=NULL) && (array.size() == 
                 size+numberEmpty+1);
       return;
    }
    // Equivalent to add(0,e).
    // Throws IllegalArgumentException if e is null
    // Target Complexity: O(1)
    public void addFirst(T e){
      add(0,e);
    }
    
    // Equivalent to add(e).
    // Throws IllegalArgumentException if e is null
    // Target Complexity: O(1)
    public void addLast(T e){
      add(e);
    }
     
    
    // Add all of the elements (if any) in Collection c to the end 
    // of the list, one-by-one.
    // Returns true if this list changed as a result of the call.
    // Throws NullPointerException if the specified collection is null
    // Target Complexity: O(number of elements in c)
    @SuppressWarnings("unchecked")
    public boolean addAll(Collection<? extends T> c){
      if(c == null){
        throw new NullPointerException();
      }
      boolean change = false;
      int beforeaddall = size;
      T[] toarray = (T[])c.toArray();//Converts it into an array
      for(int i = 0;i < toarray.length;i++){
        add(toarray[i]);
      }
      if(beforeaddall != size){
        change = true;
      }
      return change;
    }
    


// Returns true if this list contains the specified element.
    // Throws IllegalArgumentException if e is null
    // May call indexOf(e)
    // Target Complexity: O(n)
    public boolean contains(T e){
      if(e == null){throw new IllegalArgumentException();}
      String temp = e + ""; 
      for(int i = 0;i < array.size();i++){
        String h = array.get(i).data + "";//Adds it to the string and equates it with e
        if(h.equals(temp)){
          return true;
        }
      }
      return false;
    }
    
    // Returns the index of the first occurrence of the 
    // specified element in this list,
    // or NULL if this list does not contain the element.
    // Throws IllegalArgumentException if e is null
    // Target Complexity: O(n)
    public int indexOf(T e){
      if(e == null){throw new IllegalArgumentException();}
      int h = array.get(0).next;
      int count = 0;
      for(int i = 0;i < array.size();i++){
        if(h == NULL){
          continue;
        }
        if(array.get(h).next != NULL && array.get(h).data != null){
          if(array.get(h).data == e){
            return count;
          }
          count++;
        }
        else if(array.get(h).previous != NULL && array.get(h).data != null){
          if(array.get(h).data == e){
            return count;
          }
          count++;
        }
        
        if(array.get(h).next == NULL){
          continue;
        }
        else{
          h = array.get(h).next;
        }
      }
      return NULL;
    }
    
    // Returns the array position of the first occurrence of 
   // the specified element in array
   // or NULL (-1) if this list does not contain the element. 
   // Note that the return value is a position in the array, 
   // not the index of an element in the list.
   // Called by remove(T e) to find the position of e in the array.
   // Throws IllegalArgumentException if e is null
   // Target Complexity: O(n)
    protected int positionOf(T e){
      if(e == null){throw new IllegalArgumentException();}
      String temp = e + "";
      for(int i = 0;i < array.size();i++){
        String h = array.get(i).data + "";
        if(h.equals(temp)){
          return i;
        }
      }
      return NULL;
    }
    
    // Returns the element at the specified index in this list.
    // Throws IndexOutOfBoundsException if the index is out 
    // of range (index < 0 || index >= size())
    // Target Complexity: O(n)
    public T get(int index){
      if(index < 0 || index >= size()){
        throw new IndexOutOfBoundsException();
      }
      int h = array.get(0).next;
      int count = 0;
      for(int i = 1;i < array.size();i++){
        if(h == NULL){
          continue;
        }
        if(array.get(h).next != NULL && array.get(h).data != null){
          if(count == index){
            return array.get(h).data;
          }
          count++;
        }
        else if(array.get(h).previous != NULL && array.get(h).data != null){
          if(count == index){
            return array.get(h).data;
          }
          count++;
        }
        
        if(array.get(h).next == NULL){
          continue;
        }
        else{
          h = array.get(h).next;
        }
      }
      T temp = array.get(h).data;
      return temp;
    }
    
    // Returns the first element in the list.
    // Throws NoSuchElementException if the list is empty
    // Target Complexity: O(1)
    public T getFirst(){
      if(array.size() == 1){
        throw new NoSuchElementException();
      }
      int index = array.get(head).next;
      return array.get(index).data;
    }
    
    // Returns the last element in the list
    // Throws NoSuchElementException if the list is empty
    // Target Complexity: O(1)
    public T getLast(){
      if(array.size() == 1){
        throw new NoSuchElementException();
      }
      return array.get(tail).data;
    }
    
    
    // Remove the node at position current in the array.
    // Note that current is a position in the array, not the 
    // index of an element in the list.
    // The removed node is made empty and added to the front 
    // of the list of empty Nodes.
    // Called by remove(T e) and remove(int index) to 
    // remove the target Node.
    // Target Complexity: O(1)
    protected void removeNode(int current) {
      assert current > 0 && current <= array.size();
      //MY CODE
      if(current == tail){
        int j = array.get(current).previous;
        array.get(j).next = NULL;
        array.get(current).init();
        tail = j;
        this.numberEmpty++;
        this.size--;
        if(getFirstEmpty() == NULL){
         firstEmpty = 1;
       }
       else{
         array.get(current).next = getFirstEmpty();
         this.firstEmpty = current;
       }
        return;
      }
      
      int n = array.get(current).next;
      int p = array.get(current).previous;
       array.get(n).previous = p;
       array.get(p).next = n;
       array.get(current).init();
       if(getFirstEmpty() == NULL){
         firstEmpty = current;
       }
       else{
         array.get(current).next = getFirstEmpty();
         this.firstEmpty = current;
       }
       
       this.numberEmpty++;
       this.size--;
       //ENDS HERE
    }
    
    // Removes the first occurrence of the specified element from 
    // this list, if it is present. Returns true if this
    // list contained the specified element.
    // Throws IllegalArgumentException if e is null.
    // Checks assertions at the start and end of its execution.
    // Target Complexity: O(n)
    public boolean remove(T e) {
      
       assert size>=0 && head==0 && numberEmpty >=0
        && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
          && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
       //MY CODE
       if(e == null){
         throw new IllegalArgumentException();
       }
       for(int i = 1;i < array.size();i++){
         String h = array.get(i).data + "";
         String j = e + "";
        
         if(h.equals(j) && i == tail){
           
           removeNode(i);
           
           return true;
         }
         if(h.equals(j)){ 
        
           removeNode(i);
           return true;
         }
       }
       //ENDS HERE
       // check this assertion before each return statement
       assert size>=0 && head==0 && numberEmpty >=0 
         && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
          && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
       return false;
    }
    
        // Removes the element at the specified index in this list.
    // Shifts any subsequent elements to the left (subtracts one from
    // their indices). Returns the element that was removed from the 
    // list. Throws IndexOutOfBoundsException if the index is 
    // out of range (index < 0 || index >= size)
    // Checks assertions at the start and end of its execution.
    // Target Complexity: O(n)
    public T remove(int index) {
      assert size>=0 && head==0 && numberEmpty >=0 
        && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
          && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
//MY CODE
       if(index < 0 || index >= size){
         throw new IndexOutOfBoundsException();
       }

       int removenode = NULL;
       int count = 0 ;
       int h = array.get(0).next;
       
       for(int i = 0;i < array.size();i++){
         if(h == NULL){
           continue;
         }
         if(array.get(h).next == NULL && array.get(h).data != null){
           if(index == count){
             removenode = h;
           }
           count++;
         }
         else if(array.get(h).previous != NULL && array.get(h).data != null){
           if(index == count){
             removenode = h;
           }
           count++; 
         }
         if(array.get(i).next == NULL){continue;}
         else{h = array.get(h).next;}
       }
       T rn = array.get(removenode).data;
       removeNode(removenode);
   //ENDS HERE    
       
       // check this assertion before each return statement
       assert size>=0 && head==0 && numberEmpty >=0 && (numberEmpty==0 
        && firstEmpty==NULL) || (numberEmpty>0 && firstEmpty!=NULL) 
        && (array.size() == size+numberEmpty+1);
        return rn;
    }
    
    
    // Returns the first element in the list.
    // Throws NoSuchElementException if the list is empty.
    // Equivalent to remove(0), for index 0
    // Target Complexity: O(1)
    public T removeFirst(){
      if(size == 0){throw new NoSuchElementException();}
     return remove(0);
    }
 
    // Returns the last element in the list
    // Throws NoSuchElementException if the list is empty
    // Equivalent to remove(size-1), for index size-1
    // Target Complexity: O(1)
    public T removeLast(){
      if(size == 0){throw new NoSuchElementException();}
       return remove(size-1);
    }
    
    // Returns number of empty nodes.
    // Target Complexity: O(1)
    protected int numEmpty(){
      return numberEmpty();
    }
    
    
    // Returns true if the Node at the specified position in the 
    // array is an empty node.
    // Target Complexity: O(1)
    protected boolean positionIsEmpty(int position) {
      assert position >= 0 && position < array.size();
      if(position == 0){position = 1;}
      return array.get(position).data == null;
    }
    
     
    // Replaces the element at the specified position in this 
    // list with the specified element. Returns the element 
    // previously at the specified position.    
    // Throws IllegalArgumentException if e is null.
    // Throws IndexOutOfBoundsException if index is out of 
    // range (index < 0 || index >= size)
    // Target Complexity: O(n)
    public T set(int index, T e){
      if(e == null){
        throw new IllegalArgumentException();
      }
     
      if(index < 0 || index >= size){
        throw new IndexOutOfBoundsException();
      }
      
      T element = null;
      int h = array.get(0).next;  
      int count = 0;
      for(int i = 0;i < array.size();i++){
        if(h == NULL){
          continue;
        }
        if(array.get(h).next != NULL && array.get(h).data != null){
          
          if(count == index){
           
            element = array.get(h).data;
            array.get(h).data = e;
          }
          count++;
        }
        else if(array.get(h).previous != NULL && array.get(h).data != null){
          if(count == index){
            element = array.get(h).data;
            array.get(h).data = e;
          }
          count++;
        }
        
        if(array.get(h).next == NULL){
          continue;
        }
        else{
          h = array.get(h).next;
        } 
      }
      return element;
    }
 
    // Removes all of the elements from this list. 
    // The list will be empty after this call returns.
    // The array will only contain the dummy head node.
    // Some data members are reinitialized and all Nodes
    // are released to the node pool. modCount is incremented.
    // Target Complexity: O(n)
    public void clear() {
       assert size>=0 && head==0 && numberEmpty >=0 
        && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
        && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
     //MY CODE  
              
       for(int i = 1;i < array.size();i++){
         array.get(i).init();
         pool.release(array.get(i));
       }
       array.clear();
       Node<T> tempdummy = new Node<T>();
       tempdummy.init();
       array.add(tempdummy);
       size = 0;
       numberEmpty = 0;
       firstEmpty = NULL;
       tail = 0;
       modCount++;
       // check this assertion before each return statement
       assert size==0 && head==0 && numberEmpty==0 && firstEmpty==NULL
       && (array.size() == size+numberEmpty+1);
       return;
       //ENDS HERE
    }
    
    // Returns an Iterator of the elements in this list, 
    // starting at the front of the list
    // Target Complexity: O(1)
    Iterator<T> iterator(){
      return new ArrayLinkedListIterator();
    }
    
    // Convenience debugging method to display the internal 
    // values of the list, including ArrayList array
    protected void dump() {
      System.out.println();
      System.out.println("**** dump start ****");
      System.out.println("size:" + size);
      System.out.println("number empty:" + numberEmpty);
      System.out.println("first empty:"+firstEmpty);
      System.out.println("head:" + head);
      System.out.println("tail:" + tail); 
      System.out.println("list:");
      System.out.println("array:");
      for (int i=0; i<array.size(); i++) // show all elements of array
         System.out.println(i + ": " + array.get(i));
      System.out.println("**** dump end ****");
      System.out.println();
    }
    
     
    // Returns a textual representation of the list, i.e., the 
    // data values of the non-empty nodes in list order.
     public String toString(){
       
       if(size == 0){
         return "";
       }
       String ans = "";
       int h = array.get(0).next;
       for(int i = 1;i < array.size();i++){
         
         if(h == NULL){
           continue;
         }
        
         if(array.get(h).next != NULL && array.get(h).data != null){
           ans += array.get(h).data + " ";
         }
         else if(array.get(h).data != null && array.get(h).next == NULL){
          
           ans += array.get(h).data + "";
           h = NULL;
           continue;
        }
         if(array.get(h).next == NULL){
           continue;
         }
         else{
           h = array.get(h).next;
         } 
       }
       return ans;
     }
     
     
     // Compress the array by releasing all of the empty nodes to the 
     // node pool.  A new array is created in which the order of the 
     // Nodes in the new array matches the order of the elements in the 
     // list. When compress completes, there are no empty nodes. Resets 
     // tail accordingly.
     // Target Complexity: O(n)
     public void compress(){
       ArrayList<Node<T>> newOne = new ArrayList<Node<T>>();

       
       newOne.add(array.get(0));
       Node<T> ta = null;
       Node<T> ha = null;
       if(size != 0){
         ta = array.get(tail);
         ha = array.get(array.get(head).next);
       }
       int n = 0;
       int p = 0;
       for(int i = 1;i < array.size();i++){
         T e = array.get(i).data;
         
         if(array.get(i).data != null){
           newOne.add(array.get(i));
         }
         else{
            pool.release(array.get(i));
            if(size == 0){continue;}
            if(i < array.size()){
              if((i+1) != array.size()){ 
                n = array.get(i+1).next;
                p = array.get(i+1).previous;
                newOne.get(p).next = i;
                if(n == -1){
                  continue;
                }
                else{
                  array.get(n).previous = i;
                }
                if(size == 0){ continue;}
                else{array.get(i+1).next--;}
              }
            }
            
         }
       }
       firstEmpty = NULL;
       numberEmpty = 0;
       if(size != 0){
         newOne.get(head).next = newOne.indexOf(ha);
         tail = newOne.indexOf(ta);
       }
       array = newOne;
     }
     
     
      
    // Iterator for ArrayLinkedList. (See the description below.)
    private class ArrayLinkedListIterator implements Iterator<T> {
      
      private int index;
      
      // Constructor
      // Target Complexity: O(1)
      public ArrayLinkedListIterator(){
        index = 0;
      }
 
      // Returns true if the iterator can be moved to the next() element.re,m
      @SuppressWarnings("unchecked")
      public boolean hasNext(){
        
        return index < size;
      }
 
      // Move the iterator forward and return the passed-over element
      public T next(){
        assert index != size;
        if(index == size){throw new NoSuchElementException("The ArrayLinkedList ends here");}
        T a = get(index);
        index++;
        return a;
      }
 
      // The following operation is part of the Iterator interface 
      // but is not supported by the iterator. 
      // Throws an UnsupportedOperationException if invoked.
      public void remove(){
        throw new UnsupportedOperationException();
      }
   }
    
    
    
  public static void main(String args[]) {
      ArrayLinkedList<String> list = new
         ArrayLinkedList<String>();
      System.out.println("list.add(\"one\")");
      list.add("one");
      System.out.println();
      System.out.println("list:");
      System.out.println(list);
      list.dump();
      System.out.println();
      System.out.println("list.add(\"two\")");
      list.add("two");
      System.out.println();
      System.out.println("list:");
      System.out.println(list);
      list.dump();
      System.out.println();
      System.out.println("list.indexOf(\"one\"):" + 
        list.indexOf("one"));
      System.out.println("list.indexOf(\"two\"):" + 
        list.indexOf("two"));
      System.out.println("list.positionOf(\"one\"):" + 
        list.positionOf("one"));
      System.out.println("list.positionOf(\"two\"):" + 
        list.positionOf("two"));
      System.out.println();
      System.out.println("remove(new Integer(\"one\")");
      list.remove("one");
      System.out.println();
      System.out.println("list:");
      System.out.println(list);
      list.dump();
      System.out.println();
      System.out.println("add(\"three\")");
      list.add("three");
      System.out.println();
      System.out.println("list:");
      System.out.println(list);
      list.dump();
      System.out.println();
      System.out.println("add(\"four\")");
      list.add("four");
      System.out.println();
      System.out.println("list:");
      System.out.println(list);
      list.dump();
      System.out.println();
      // list is now: two three four
      // remove element at index 1, which is "three"
      System.out.println("remove(1)"); 
      list.remove(1);
      System.out.println();
      System.out.println("list:");
      System.out.println(list);
      list.dump();
      System.out.println();
      System.out.println("compress"); 
      list.compress();
      System.out.println();
      System.out.println("list:");
      System.out.println(list);
      list.dump();
      System.out.println();
      System.out.println("list.clear()");
      list.clear();
      System.out.println();
      System.out.println("list:");
      System.out.println(list);
      list.dump(); // array contains dummy node only
    }  
}